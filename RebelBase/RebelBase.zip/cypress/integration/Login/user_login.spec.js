/// <reference types="cypress" />


const startStr = "token="
const endStr = "&"
var existinguser = Cypress.env('emailuser')

function extractData(data, startStr, endStr) {
  var subStrStart = data.indexOf(startStr) + startStr.length
  return data.substring(subStrStart,
    subStrStart + data.substring(subStrStart).indexOf(endStr));

}
describe('', () => {
  // Show error popup when either email or password is missing

  it('Email is missing [loginFlowTest]', () => {
    cy.visit('/');
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.contains('Login >').click();
    cy.getCookie('token').should('not.exist');
    cy.contains('Please enter a valid email.');
  });

  it('Password is less than 6 char[loginFlowTest]', () => {
    cy.visit('/');
    //cy.contains('Got it').click();

    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.contains('Login >').click();

    cy.getCookie('token').should('not.exist');
    cy.contains('Password must be at least 6 characters long');
  });

  // Either email or password is incorrect
  it('Invalid login Id or passwd details [loginFlowTest]', () => {
    cy.visit('/');
    //cy.contains('Got it').click();

    cy.get('input[name="email"]').type('invalidtestgroupmember@gmail');
    cy.get('input[name="password"]').type('testtest');
    cy.contains('Login >').click();

    cy.getCookie('token').should('not.exist');
    cy.contains('Please enter a valid email.');

    cy.get('input[name="email"]').clear();
    cy.get('input[name="password"]').clear();
    cy.get('input[name="email"]').type('testhubadmin@rebelbase.co');
    cy.get('input[name="password"]').type('testtest12');
    cy.contains('Login >').click();
    cy.contains('Incorrect email or password.');
  });

  it('Autofill email address if exist in url [loginFlowTest]', () => {
    cy.visit(
      `https://staging.rebelbase.co/accept/project-invitation/?token=${Cypress.env(
        'token'
      )}&email_address=${Cypress.env('username')}`
    );
    //cy.contains('Got it').click();
    cy.get('input[name="email"]').should('have.value', Cypress.env('username'));
    cy.contains('Please signup or login before trying to accept an invitation to create a Hub.');
  });

  it('Should login and redirect to profile [loginFlowTest]', () => {

    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.wait(5000);
    cy.location('pathname').should('equal', '/profile/2466');
    cy.get('.notification > :nth-child(3)').contains(
      `Please verify your email address: ${Cypress.env('username')}`
    );
  });

  it('Log in, go to profile then logout [loginFlowTest]', () => {


    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.wait(5000);
    // confirm we have logged in successfully
    cy.location('pathname').should('equal', '/profile/2466');
    cy.wait(5000);
    // now we can log out
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();

    // cy.window().its('store').invoke('dispatch', deleteSession());
    cy.location('pathname').should('equal', '/auth/login');

  });

  it('Autofill email address if exist in url, existing user log in and accept invitation [loginFlowTest]', () => {

    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.wait(5000);
    //cy.get(':nth-child(3) > .arrow-up').click();
    cy.get('.sideNav__add-team-btn').click({
      force: true
    });
    cy.get('.inviteForm__input').clear();
    cy.get('.inviteForm__input').type('rebelbasetesthub@gmail.com');

    cy.get('.inviteTeam__btn').click();
    cy.get('.btn-x').click({
      force: true
    })
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000);

    cy.task("gmail:get-messages", {

      options: {
        from: "info@rebelbase.co",
        subject: "Join CypressTestProject01 team on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );
      const body = emails[0].body.html;
      console.log(body)
      cy.log(body);

      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/accept/project-invitation/?token="
        ) >= 0,
        "Found link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `accept/project-invitation/?token=${token}&email_address=rebelbasetesthub@gmail.com`
      );


      cy.get('input[name="email"]').should('have.value', 'rebelbasetesthub@gmail.com');
      cy.contains('Please signup or login before trying to accept an invitation to create a Hub.');
      cy.get('.notification-dismiss').click();
      cy.get('input[name="password"]').type(Cypress.env('password'));
      cy.contains('button', 'Login >').click();
      cy.wait(3000);
      //cy.location('pathname').should('equal', '/project/1511/builders');
      cy.contains('Project invitation accepted!');
      cy.get('.notification-dismiss').click({
        multiple: true
      });
      cy.get('[data-testid=ArrowDropDownIcon]').click();
      cy.get('[data-testid=SettingsIcon]').click();

      cy.get('.sideBar > ul > :nth-child(3)').contains('CypressTestProject01').click({
        force: true
      });
      cy.get('.team__change-role__drop').click();
      cy.get('button.btn-link-alarm').contains('Leave project').click({
        force: true
      })
      cy.get('.notification').contains('You have left the project!');
    });
  });

  it('project invitation from support member', () => {

    cy.login(Cypress.env('username'), Cypress.env('password'));
    cy.wait(5000);
    //cy.get(':nth-child(3) > .arrow-up').click();
    cy.get('.sideNav__add-team-btn').click({
      force: true
    });
    cy.get('.inviteForm__input').clear();
    cy.get('.inviteForm__input').type('rebelbasetesthub@gmail.com');
    cy.get('select.form-control').select('4');
    cy.get('.inviteTeam__btn').click();
    cy.get('.btn-x').click({
      force: true
    })
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000);

    cy.task("gmail:get-messages", {

      options: {
        from: "info@rebelbase.co",
        subject: "Join CypressTestProject01 team on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );
      const body = emails[0].body.html;
      console.log(body)
      cy.log(body);

      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/accept/project-invitation/?token="
        ) >= 0,
        "Found link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `accept/project-invitation/?token=${token}&email_address=rebelbasetesthub@gmail.com`
      );


      cy.get('input[name="email"]').should('have.value', 'rebelbasetesthub@gmail.com');
      cy.contains('Please signup or login before trying to accept an invitation to create a Hub.');
      cy.get('.notification-dismiss').click();
      cy.get('input[name="password"]').type(Cypress.env('password'));
      cy.contains('button', 'Login >').click();
      cy.wait(7000);
      //cy.location('pathname').should('equal', '/project/1511/builders');
      cy.contains('Project invitation accepted!');
      cy.get('.notification-dismiss').click({
        multiple: true
      });
      cy.get('[data-testid=ArrowDropDownIcon]').click();
      cy.get('[data-testid=SettingsIcon]').click();

      cy.get('.sideBar > ul > :nth-child(3)').contains('CypressTestProject01').click({
        force: true
      });
      cy.get('.team__change-role__drop').click();
      cy.get('button.btn-link-alarm').contains('Leave project').click({
        force: true
      })
      cy.get('.notification').contains('You have left the project!');
    });
  });
  it('Log in with different email and try to accept project invitation token [loginFlowTest] ', () => {
    cy.visit(
      `accept/project-invitation/?token=${Cypress.env(
        'projectinvitation'
      )}&email_address=${Cypress.env('username')}`
    );
    //cy.contains('Got it').click();
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(Cypress.env('username2'));
    cy.contains(
      'You will not be able to accept the invitation using this email address.'
    );
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.get('.login__btn').click();
    cy.wait(5000);
    // cy.login('user2');
    cy.location('pathname').should('equal', '/profile/2469');
    //cy.loginAndAcceptProjectInvitation(403);
    cy.contains(
      'This invitation has expired!'
    );
  });
  /*
  //not completed below , need to check what is invalid token
  it('Log in with invalid project invitation token [loginFlowTest]', () => {
    cy.visit('/');
    //cy.contains('Got it').click();

    cy.get('input[name="email"]').type(Cypress.env('username2'));
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.wait(6000)
    cy.location('pathname').should('equal', '/profile/2428');
    cy.contains('Invalid token!');
  });
  //not completed role type need to check 
  it('Autofill email address if exist in url, log in and accept event invitation [loginFlowTest]', () => {


    cy.visit(
      `http://app.staging.rebelbase.co/accept/hub-event-invitation/?token=${Cypress.env(
        'token'
      )}&email_address=${Cypress.env('emailuser')}`
    );
    //cy.contains('Got it').click();
    cy.get('input[name="email"]').should('have.value', Cypress.env('emailuser'));
    cy.contains(
      'Please signup or login before trying to accept an event invitation.'
    );
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.location('pathname').should('equal', '/profile/3384');
    cy.contains(
      `Please verify your email address: ${Cypress.env('emailuser')}.`
    );
    cy.wait(5000);
    const roleType = [1, 2, 4, 6];
    roleType.map((role) => {
      cy.loginAndAcceptEventInvitation(200, role);
      if (role === 2)
        cy.location('pathname').should('equal', `/events/55/select-project`);
      else if (role === 4)
        cy.location('pathname').should('equal', `/events/55/welcome-judge`);
      else if (role === 6)
        cy.location('pathname').should('equal', `/events/55/welcome-resource`);
      else cy.location('pathname').should('equal', `/events/55`);
      cy.contains('Invitation accepted successfully.');
      cy.wait(5000);
    });
  });
*/
  it('Autofill email address if exist in url, log in and accept event invitation [loginFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit('/');
    // cy.get('.button-close').click();
    cy.get('.login__noaccount > button').click();
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('testtest');
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type('sur');
    cy.get('[name="email"]').clear();
    cy.get('[name="email"]').type(randomEmail);
    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();
    cy.get('.sign-up__btn').click({
      force: true
    });
    cy.wait(10000);
    cy.url().should('include', '/profile');
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({
      force: true
    });
    cy.get('[aria-label="menu"] > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').contains('test')
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.task('setUserId', randomEmail);

    cy.task('getUserId').then((userId) => {
      cy.log(userId)
      window.userId = userId;
    });
    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/events/143');
    cy.wait(5000);
    cy.get(':nth-child(1) > .btn-main').click();
    cy.get('.createEvent__title').contains('Invite Participants');
    cy.get('select').select('Competitor').should('have.value', '2');
    cy.get("input[placeholder='Add multiple email addresses one at a time']").clear()
    cy.task('getUserId').then((userId) => {
      cy.get("input[placeholder='Add multiple email addresses one at a time']").type(userId);
    });
    cy.get('.btn-wrap > .btn-main').click();
    cy.get('.feedback__message').contains('Succesfully sent invite to:')
    cy.get('.btn-x').click();
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)

    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "Join test at cypresstestevent via RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );

      const body = emails[0].body.html;
      assert.isTrue(
        body.indexOf(

          "token="

        ) >= 0,
        "Found reset link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `accept/hub-event-invitation/?token=${token}&email_address=${userId}`
      );

      cy.get('input[name="email"]').should('have.value', userId);
      cy.contains(
        'Please signup or login before trying to accept an invitation to create a Hub.'
      );
      cy.get('input[name="password"]').type(Cypress.env('password'));
      cy.get('.login__btn').click();
      cy.wait(5000)
      cy.location('pathname').should('equal', `/events/143/select-project`);
      cy.contains('Invitation accepted successfully.');

    });

  });


  it('log in with different email and try to accept event invitation token [loginFlowTest]', () => {
    cy.visit(
      `https://staging.rebelbase.co/accept/hub-event-invitation/?token=${Cypress.env(
        'eventinvitation'
      )}&email_address=${Cypress.env('emailuser')}`
    );
    //cy.contains('Got it').click();
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(Cypress.env('username2'));
    cy.contains(
      'You will not be able to accept the invitation using this email address.'
    );
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.get('.login__btn').click();
    cy.wait(8000)
    cy.location('pathname').should('equal', '/profile/2469');

    cy.contains(

      'This invitation has expired!'
    );
  });
  //need to check invalid token concept
  it('log in with invalid event invitation token [loginFlowTest]', () => {
    cy.visit(
      `https://staging.rebelbase.co/accept/hub-event-invitation/?token=${Cypress.env(
        'token2'
      )}&email_address=${Cypress.env('emailuser')}`
    );
    //cy.contains('Got it').click();
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(Cypress.env('emailuser'));

    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.get('.login__btn').click();
    cy.wait(8000);
    cy.location('pathname').should('equal', '/profile/4410');
    cy.contains('This invitation has expired!');
  });

  it('Autofill email address if exist in url, log in and accept hub invitation [loginFlowTest]', () => {

    cy.visit('/');
    // cy.get('.button-close').click();
    cy.get('.login__noaccount > button').click();
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('testtest');
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type('sur');
    cy.get('[name="email"]').clear();
    cy.get('[name="email"]').type(Cypress.config('email_verify'));
    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();

    cy.get('.sign-up__btn').click({
      force: true
    });
    cy.wait(10000);
    cy.url().should('include', '/profile');
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({
      force: true
    });
    cy.get('[aria-label="menu"] > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').contains('test');
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();

    cy.visit('/');

    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/hubs/26/activity');
    cy.wait(8000);
    cy.get('.hub__topHeader__dropdown__links').contains('Invite Members').click({
      force: true
    })
    cy.get('.notification-dismiss').click();
    cy.get('.modal-title-h3').contains('Invite Members to Dev Hub');
    cy.get('.multi_email > input').click({
      force: true
    });
    cy.get('.multi_email > input').type(Cypress.config('email_verify'));
    cy.get('.btn-send').click()
    cy.get('.btn-x').click({
      force: true
    });

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)

    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "test invited you to join the Dev Hub hub on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );

      const body = emails[0].body.html;
      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/accept/hub-invitation/?token="

        ) >= 0,
        "Found reset link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `accept/hub-invitation/?token=${token}&email_address=${Cypress.config('email_verify')}`
      );

      //cy.contains('Got it').click();
      cy.get('input[name="email"]').should('have.value', Cypress.config('email_verify'));
      cy.contains(
        'Please signup or login before trying to accept an invitation to create a Hub.'
      );
      cy.get('input[name="password"]').type(Cypress.env('password'));
      cy.get('.login__btn').click();
      cy.wait(5000);
      cy.location('pathname').should('equal', `/hubs/26/welcome`);
      cy.get('.notification').contains('Invitation accepted successfully.')


    });
  });
  it('log in with different email and try to accept hub invitation token [loginFlowTest]', () => {
    cy.visit(
      `accept/hub-invitation/?token=${Cypress.env(
        'hubinvitation'
      )}&email_address=${Cypress.config('email_verify')}`
    );
    //cy.contains('Got it').click();
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(Cypress.env('username2'));
    cy.contains(
      'You will not be able to accept the invitation using this email address.'
    );
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.get('.login__btn').click();
    cy.wait(7000)
    //cy.login('user2');
    cy.location('pathname').should('equal', '/profile/2469');

    cy.contains(
      'This invitation has expired!'
    );
  });
  /* need to modify
    it('log in with invalid hub invitation token [loginFlowTest]', () => {
      cy.visit('/');
      //cy.contains('Got it').click();

      cy.get('input[name="email"]').type(Cypress.env('username2'));
      cy.get('input[name="password"]').type(Cypress.env('password'));
      cy.login('user2');
      cy.location('pathname').should('equal', '/profile/2428');
      cy.contains(
        `Please verify your email address: ${Cypress.env('username2')}.`
      );
      cy.loginAndAcceptHubInvitation(422);

      cy.contains('Invalid token!');
    });
    */
    it('show popup message to complete tell-us ,until tell-us is complete', () => {
      const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
      cy.visit('/');
      // cy.get('.button-close').click();
      cy.get('.login__noaccount > button').click();
      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type('testtest');
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type('sur');
      cy.get('[name="email"]').clear();
      cy.get('[name="email"]').type(randomEmail);
      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(10000);
      cy.url().should('include', '/profile');
      cy.get('[aria-label="menu"] > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').contains('test')
      cy.get('[data-testid=ArrowDropDownIcon]').click({force: true});
      cy.get('[data-testid=LogoutIcon]').click({force: true});
      cy.visit('/');
      cy.get('[name="email"]').type(randomEmail);
      cy.get('[name="password"]').type(Cypress.env('password'));
      cy.contains('Login >').click();
      cy.wait(5000);
      cy.get('.popUp__note').contains("Tell us about yourself... then we can customize your experience!");
      cy.xpath("(//button[normalize-space()='Click Here'])[1]").click();

      cy.get('.notification-dismiss').click({ multiple: true });
      cy.get('.tellus').find('h2').contains('Tell us a little about yourself');
      cy.get('.tellus__dropdown').type('Chennai, Tamil Nadu, India');
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      cy.contains('button', 'READY!').click();
   //   cy.location('pathname').should('equal', '/avatar-upload');
   //   cy.get('.btn-x').contains('x').click();
      cy.url().should("contain", '/profile');
    });

    it.skip('fails to access protected resource', () => {
      cy.request({
        url: 'https://core-service.staging.rebelbase.co/api/v1/rebel/settings/users',
        failOnStatusCode: false,
      })
        .its('status')
        .should('equal', 200);
        cy.get('404 page')
    });
    

});