describe('', () => {
  // show error if required field is missing, email is invalid or already taken,
  // password is smaller then 6 character, confirm password doesn't match password
  // show signuppage, tellus, avatar-upload, way-find
  // show error if tell-us is empty
  // based on way-find option selected show respected page

  const startStr = "token="
  const endStr = "&"

  function extractData(data, startStr, endStr) {
    var subStrStart = data.indexOf(startStr) + startStr.length
    return data.substring(subStrStart,
      subStrStart + data.substring(subStrStart).indexOf(endStr));

  }

  it('required field is missing [SignUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit('/');
    // cy.get('.button-close').click();
    // cy.contains('Got it').click();
    cy.get('.login__noaccount > button').click();
    // cy.get('.public__signup-btn').click();
    cy.url().should('include', '/sign-up');
    cy.get('input[name="firstName"]').focus().blur();
    cy.contains('Required');
    cy.get('input[name="firstName"]').type(Cypress.env('firstName'));
    cy.get('input[name="lastName"]').focus().blur();
    cy.contains('Required');
    cy.get('input[name="lastName"]').type(Cypress.env('lastName'));
    cy.get('input[name="email"]').focus().blur();
    cy.contains('Required');
    cy.get('input[name="email"]').type(Cypress.env('invalidEmail'));
    cy.contains('Please enter a valid email.');
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.get('input[name="password"]').focus().blur();
    cy.contains('Required');
    cy.get('input[name="password"]').type('1234');
    cy.contains('Password must be at least 6 characters long');
    cy.get('input[name="password"]').clear();
    cy.get('input[name="password"]').type(Cypress.env('password'));
    cy.get('input[name="confirmPassword"]').focus().blur();
    cy.contains('Required');
    cy.get('input[name="confirmPassword"]').type('123456');
    cy.contains('Password does not match');
    cy.get('input[name="confirmPassword"]').clear();
    cy.get('input[name="confirmPassword"]').type(Cypress.env('password'));
    cy.contains('Get Started >').click();
    cy.url().should('include', '/sign-up');
    cy.getCookie('token').should('not.exist');
    cy.contains('Hm... looks like we skipped a mandatory field.');
    cy.get('#allowAll').check();
    cy.get('#promotionalEmails').check();
    cy.get('.notification-dismiss').click();
    cy.contains('Get Started >').click();

    cy.contains(
      'Darn...that email address has already been taken. If this is you, log in instead.'
    );
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(randomEmail);
    cy.get('.notification-dismiss').click();
    cy.contains('Get Started >').click();
    cy.wait(2000);
    // cy.url().should('have.text', '/profile');
    cy.get('.tellus > h2').should('have.text', 'Tell us a little about yourself');
    cy.get('.tellus__dropdown').type('Chennai, Tamil Nadu, India');
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    cy.contains('button', 'READY!').click();

    cy.wait(2000);

    cy.contains('button', 'skip for now >').click({
      force: true
    });
    //cy.location('pathname').should('equal', '/way-find');
    //cy.wait(5000);
    //cy.get('.indicator').contains('Create a project.').click();
    //cy.location('pathname').should('equal', '/create-project');
    //cy.get(':nth-child(1) > :nth-child(2) > .form-control').type(randomEmail);
    //cy.get('#-google-places-autocomplete-input').type('Pune, Maharashtra, India');
    //cy.get('[for="stageChoice1"] > h4').click();
    //cy.get('select').select('Energy');
    //cy.get('.cProj__btn').click();

    //cy.visit('/way-find');
    //cy.wait(8000);
    //cy.get('.indicator').contains('Browse Projects.').click();
    //cy.location('pathname').should('equal', '/browse');
    //cy.visit('/way-find');
    //cy.contains(`Please verify your email address: ${randomEmail}.`);
    //cy.get('.notification-dismiss').click();
    //cy.wait(8000);
    //cy.get('.indicator')
    // .contains('Contact us to request a Hub Invite.')
    // .click();
    //cy.location('pathname').should('equal', '/help');
    //cy.visit('/way-find');
    //cy.wait(5000);
    //cy.get('.btn-x').contains('button', 'x').click();
    cy.task('setUserId', randomEmail);
  });


  it('Signup and accept project invitation [SignUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    debugger
    //cy.contains('Got it').click();
    cy.login(Cypress.env('emailuser'), Cypress.env('password'))
    cy.wait(5000);
    cy.get('.sideNav__add-team-btn').click();
    cy.get('.inviteForm__input').clear();
    cy.get('.inviteForm__input').type(randomEmail);
    cy.get('.inviteTeam__btn').click();
    cy.get('.btn-x').click()

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(25000)

    cy.task("gmail:get-messages", {

      options: {
        from: "info@rebelbase.co",
        subject: "Join rebebasetestuserproject team on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );
      const body = emails[0].body.html;
      console.log(body)
      cy.log(body);

      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/auth/sign-up?type=project_invitation&amp;token="
        ) >= 0,
        "Found link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `auth/sign-up?type=project_invitation&token=${token}&email=${randomEmail}`
      );
      cy.wait(3000);

      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type(randomEmail);
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type(randomEmail);

      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(2000);
      cy.get('#-google-places-autocomplete-input').type('p')
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      cy.get('.tellus__wrap > .btn-main').click();
      cy.get('.btn-skip').click({
        force: true
      });
      cy.get('.notification-success').contains('Project invitation accepted!')
      // cy.get('.notification').contains('Invalid Token!')
      cy.get('.notification-dismiss').click();
      cy.url().should('include', '/builders');

    });

  });

  it('Sign up with different email and try to accept project invitation token [signUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.login(Cypress.env('emailuser'), Cypress.env('password'))
    cy.wait(5000);
    cy.get('.sideNav__add-team-btn').click();
    cy.get('.inviteForm__input').clear();
    cy.get('.inviteForm__input').type(randomEmail);
    cy.get('select').select('Admin')
    cy.get('.inviteTeam__btn').click();
    cy.get('.btn-x').click()

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(25000)

    cy.task("gmail:get-messages", {

      options: {
        from: "info@rebelbase.co",
        subject: "Join rebebasetestuserproject team on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );
      const body = emails[0].body.html;
      console.log(body)
      cy.log(body);

      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/auth/sign-up?type=project_invitation&amp;token="
        ) >= 0,
        "Found link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `auth/sign-up?type=project_invitation&token=${token}&email=${randomEmail}`
      );
      cy.wait(3000);

      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type(randomEmail);
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type(randomEmail);
      cy.get('input[name="email"]').clear();
      cy.get('input[name="email"]').type('h' + randomEmail);
      cy.get('.inline-warning').contains('You will not be able to accept the invitation using this email address.');
      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(2000);
      cy.get('#-google-places-autocomplete-input').type('p')
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      cy.get('.tellus__wrap > .btn-main').click();
      cy.get('.btn-skip').click({
        force: true
      });

      cy.contains(
        'Make sure you are logged in with the correct email before trying to accept an invitation!'
      );
      cy.get('.notification-dismiss').click();
    });

  });

  it('Sign up and try to accept invalid project invitation token [signUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit(
      `auth/sign-up?type=project_invitation&token=${Cypress.env('token1')}&email=${randomEmail}`
    );
    cy.wait(3000);

    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type(randomEmail);
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type(randomEmail);
    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();
    cy.get('.sign-up__btn').click({
      force: true
    });
    cy.wait(8000);
    cy.get('#-google-places-autocomplete-input').type('p')
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({
      force: true
    });
    // cy.get('.notification').contains('Invalid Token!');
    cy.contains(
      'This invitation has expired!'
    );
    cy.get('.notification-dismiss').click();


  });


  it('Sign up with different email and try to accept event invitation token [signUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit('/');
    //cy.contains('Got it').click();
    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/events/127');
    cy.wait(5000);
    cy.get(':nth-child(1) > .btn-main').click({
      force: true
    });
    cy.get('.createEvent__title').contains('Invite Participants');
    cy.get('select').select('Competitor').should('have.value', '2');
    cy.get("input[placeholder='Add multiple email addresses one at a time']").clear()
    cy.get("input[placeholder='Add multiple email addresses one at a time']").type(randomEmail)
    cy.get('.btn-wrap > .btn-main').click();
    cy.get('.feedback__message').contains('Succesfully sent invite to:')
    cy.get('.btn-x').click();

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)

    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "Join test at cypresstestevent via RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );

      const body = emails[0].body.html;
      assert.isTrue(
        body.indexOf(

          "token="

        ) >= 0,
        "Found reset link!"
      );

      window.token = extractData(body, startStr, endStr);
      cy.visit(
        `auth/sign-up?type=hub_event_invitation&token=${token}&email=${Cypress.config('email_verify')}`
      );

      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type(Cypress.config('email'));
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type(Cypress.config('email'));

      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(20000);
      cy.url().should('include', '/profile');
      cy.get('#-google-places-autocomplete-input').clear();
      cy.get('#-google-places-autocomplete-input').type('pune');
      cy.wait(2000);
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
      cy.get('.tellus__wrap > .btn-main').click();
      cy.get('.btn-skip').click({
        force: true
      });

      cy.contains(
        'Make sure you are logged in with the correct email before trying to accept an invitation!'
      );
      cy.get('.notification-dismiss').click();
    });

  });

  /* need to check how to generate invalid token */
  it('Sign up and try to accept invalid event invitation token [signUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit('/');
    //cy.contains('Got it').click();
    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/events/127');
    cy.wait(5000);
    cy.get(':nth-child(1) > .btn-main').click();
    cy.get('.createEvent__title').contains('Invite Participants');
    cy.get('select').select('Competitor').should('have.value', '2');
    cy.get("input[placeholder='Add multiple email addresses one at a time']").clear()
    cy.get("input[placeholder='Add multiple email addresses one at a time']").type(randomEmail)
    cy.get('.btn-wrap > .btn-main').click();
    cy.get('.feedback__message').contains('Succesfully sent invite to:')
    cy.get('.btn-x').click();

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();

    cy.visit(
      `auth/sign-up?type=hub_event_invitation&token=${Cypress.env('token2')}&email=${randomEmail}`
    );

    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type(randomEmail);
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type(randomEmail);

    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();
    cy.get('.sign-up__btn').click({
      force: true
    });
    cy.wait(20000);
    cy.url().should('include', '/profile');
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({
      force: true
    });
    cy.contains(
      'This invitation has expired!'
    );




  });


  it('Sign up with different email and try to accept hub invitation token [signUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/hubs/26/activity');
    cy.wait(20000);
    cy.get('.hub__topHeader__dropdown__links').contains('Invite Members').click({
      force: true
    })
    cy.get('.notification-dismiss').click();
    cy.get('.modal-title-h3').contains('Invite Members to Dev Hub');
    cy.get('.multi_email > input').type(randomEmail);
    cy.get('.btn-send').click()
    cy.get('.btn-x').click();

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)

    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "test invited you to join the Dev Hub hub on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );

      const body = emails[0].body.html;
      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/auth/sign-up?type=hub_invitation&amp;token="

        ) >= 0,
        "Found reset link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `auth/sign-up?type=hub_invitation&token=${token}&email=${randomEmail}`
      );
      //cy.wait(3000);
      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type(randomEmail);
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type(randomEmail);
      cy.get('[name="email"]').clear();
      cy.get('[name="email"]').type('h' + randomEmail)
      cy.get('.inline-warning').contains('You will not be able to accept the invitation using this email address.');
      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(20000);
      cy.url().should('include', '/profile');
      cy.get('#-google-places-autocomplete-input').clear();
      cy.get('#-google-places-autocomplete-input').type('pune');
      cy.wait(2000);
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
      cy.get('.tellus__wrap > .btn-main').click();
      cy.get('.btn-skip').click({
        force: true
      });
      cy.contains(
        'Make sure you are logged in with the correct email before trying to accept an invitation!'
      );
      // cy.get('.notification').contains('Invalid Token!')
      cy.get('.notification-dismiss').click();
    });


  });


  it('Sign up and try to accept invalid hub invitation token using link [signUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit(
      `auth/sign-up?type=hub_event_invitation&token=${Cypress.env('token2')}&email=${randomEmail}`
    );

    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type(randomEmail);
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type(randomEmail);

    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();
    cy.get('.sign-up__btn').click({
      force: true
    });
    cy.wait(20000);
    cy.url().should('include', '/profile');
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({
      force: true
    });
    cy.contains(
      'This invitation has expired!'
    );


  });




  it("new user signup and verify email account [SignUpFlowTest]", function () {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    debugger; //Uncomment for debugger to work...
    cy.visit('/');
    // cy.get('.button-close').click();
    cy.get('.login__noaccount > button').click();
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('testtest');
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type('sur');
    cy.get('[name="email"]').clear();
    cy.get('[name="email"]').type(randomEmail);
    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();
    cy.get('.sign-up__btn').click({
      force: true
    });
    cy.wait(10000);
    cy.url().should('include', '/profile');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({
      force: true
    });

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();

    cy.visit('/');
    //cy.contains('Got it').click();
    cy.login(randomEmail, 'testtest')

    cy.wait(5000);
    cy.get('.notification > :nth-child(3) > div > button').click();
    cy.wait(2000)
    cy.get('.notification').invoke('text').should('contain', 'A verification email has been sent to ');
    //cy.get('.popUp__note').contains.text('A verification email has been sent to ');
    cy.get('.notification-dismiss').click();
    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)
    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "Verify your email for your RebelBase account",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );
      const body = emails[0].body.html;
      cy.log(body)
      assert.isTrue(
        body.indexOf(
          "email-verification?token="
        ) >= 0,
        "Found reset link!"
      );


      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `email-verification?token=${token}&email_address=${randomEmail}`
      );
      //cy.wait(3000);
      cy.get('.notification').contains('Email verified!')
      // cy.get('.notification').contains('Invalid Token!')
      cy.get('.notification-dismiss').click();
    });


  });

  it.skip(' Autofill email address if exist in url [SignUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "Verify your email for your RebelBase account",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );
      const body = emails[0].body.html;

      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/email-verification?token="
        ) >= 0,
        "Found reset link!"
      );


      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `email-verification?token=${token}&email_address=${randomEmail}`
      );
      cy.wait(3000);
      //cy.get('.notification').contains('Invalid Token!')
      //cy.get('.notification-dismiss').click();

      cy.get('input[name="email"]').should('have.value', randomEmail);
    });

  });

  it('Autofill email address if exist in url and show warning if user edit email address [SignUpFlowTest]', () => {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    cy.visit(
      `auth/sign-up?type=project_invitation&token=${token}
      &email=${randomEmail}`
    );
    // 
    cy.wait(5000)
    cy.get('input[name="email"]').should('have.value', randomEmail);
    cy.get('input[name="email"]').clear();
    cy.get('input[name="email"]').type(Cypress.env('username2'));
    cy.contains(
      'You will not be able to accept the invitation using this email address.'
    );
  });

  it("new  user signup and  accept hub invitation [Hub]", function () {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    debugger; //Uncomment for debugger to work...
    cy.visit('/');
    //cy.contains('Got it').click();
    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.wait(10000);
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/hubs/26/activity');
    cy.wait(5000);
    cy.get('.hub__topHeader__dropdown__links').contains('Invite Members').click({
      force: true
    })
    cy.get('.notification-dismiss').click();
    cy.get('.modal-title-h3').contains('Invite Members to Dev Hub');
    cy.get('.multi_email > input').type(randomEmail);
    cy.get('.btn-send').click()
    cy.get('.btn-x').click();

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)

    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "test invited you to join the Dev Hub hub on RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );

      const body = emails[0].body.html;
      assert.isTrue(
        body.indexOf(
          "http://app.staging.rebelbase.co/auth/sign-up?type=hub_invitation&amp;token="

        ) >= 0,
        "Found reset link!"
      );

      window.token = extractData(body, startStr, endStr);

      cy.visit(
        `auth/sign-up?type=hub_invitation&token=${token}&email=${randomEmail}`
      );
      //cy.wait(3000);
      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type(randomEmail);
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type(randomEmail);

      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(20000);
      cy.url().should('include', '/profile');
      cy.get('#-google-places-autocomplete-input').clear();
      cy.get('#-google-places-autocomplete-input').type('pune');
      cy.wait(2000);
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
      cy.get('.tellus__wrap > .btn-main').click();
      cy.get('.btn-skip').click({
        force: true
      });
      cy.get('.notification').contains('Invitation accepted successfully.')
      // cy.get('.notification').contains('Invalid Token!')
      cy.get('.notification-success > .notification-dismiss').click();
    });


  });


  it("new  user signup and  accept event invitation [signUpFlowTest]", function () {
    const randomEmail = `rebelbasetesthub+${new Date().getTime()}@gmail.com`;
    debugger; //Uncomment for debugger to work...
    cy.visit('/');
    //cy.contains('Got it').click();
    cy.login(Cypress.env('username'), Cypress.env('password'))
    cy.wait(8000);
    cy.url().should('include', '/profile/2466');
    cy.getCookie('token').should('exist');
    cy.visit('/events/127');
    cy.wait(5000);
    cy.get(':nth-child(1) > .btn-main').click();
    cy.get('.createEvent__title').contains('Invite Participants');
    cy.get('select').select('Competitor').should('have.value', '2');
    cy.get("input[placeholder='Add multiple email addresses one at a time']").clear()
    cy.get("input[placeholder='Add multiple email addresses one at a time']").type(randomEmail)
    cy.get('.btn-wrap > .btn-main').click();
    cy.get('.feedback__message').contains('Succesfully sent invite to:')
    cy.get('.btn-x').click();

    cy.get('[data-testid=ArrowDropDownIcon]').click();
    cy.get('[data-testid=LogoutIcon]').click();
    cy.wait(20000)

    cy.task("gmail:get-messages", {
      options: {
        from: "info@rebelbase.co",
        subject: "Join test at cypresstestevent via RebelBase",
        include_body: true,
        // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
        //  after: new Date(2021, 7, 23) // After August 23, 2019
      }
    }).then(emails => {
      assert.isAtLeast(
        emails.length,
        1,
        "Expected to find at least one email, but none were found!"
      );

      const body = emails[0].body.html;
      assert.isTrue(
        body.indexOf(

          "token="

        ) >= 0,
        "Found reset link!"
      );

      window.token = extractData(body, startStr, endStr);
      cy.visit(
        `auth/sign-up?type=hub_event_invitation&token=${token}&email=${randomEmail}`
      );

      //  cy.visit(
      //   `auth/sign-up?type=hub_event_invitation&amp;token=${token}&email=${randomEmail}`
      // );
      //cy.wait(3000);
      cy.get('[name="firstName"]').clear();
      cy.get('[name="firstName"]').type(randomEmail);
      cy.get('[name="lastName"]').clear();
      cy.get('[name="lastName"]').type(randomEmail);

      cy.get('[name="password"]').clear();
      cy.get('[name="password"]').type('testtest');
      cy.get('[name="confirmPassword"]').clear();
      cy.get('[name="confirmPassword"]').type('testtest');
      cy.get('#allowAll').click();
      cy.get('#promotionalEmails').click();
      cy.get('.sign-up__btn').click({
        force: true
      });
      cy.wait(20000);
      cy.url().should('include', '/profile');
      cy.get('#-google-places-autocomplete-input').clear();
      cy.get('#-google-places-autocomplete-input').type('pune');
      cy.wait(2000);
      cy.get('#-google-places-autocomplete-suggestion--0').click();
      //cy.get(':nth-child(4) > .form-group > .purpose__label > .purpose__p').click();
      cy.get('.tellus__wrap > .btn-main').click();
      cy.get('.btn-skip').click({
        force: true
      });
      cy.get('.notification').contains('Invitation accepted successfully.')
      // cy.get('.notification').contains('Invalid Token!')
      cy.get('.notification-success > .notification-dismiss').click();
    });
  });

//not completed yet some error
  it.skip('tell-us is empty', () => {
    cy.visit('https://app.staging.rebelbase.co/');
    cy.get('.login__noaccount > button').click();
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('test');
    cy.get('.sign-up').click();
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('rebel12');
    cy.get('[name="lastName"]').click();
    cy.get('.sign-up').click();
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('rebel12');
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type('rebel12');
    cy.get('[name="email"]').clear();
    cy.get('[name="email"]').type('rebelbasetesthub+3@rebelbase.co');
    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').check();
    cy.get('#promotionalEmails').type('true');
    cy.get('.sign-up__btn').click();
    cy.wait(20000);
    cy.visit('/')
    cy.wait(20000);
    cy.get('.notifications-tc > :nth-child(1) > div').contains('Tell us');
    cy.get('.notification > div > button').click();
    cy.get('.tellus > h2').should('have.text', 'Tell us a little about yourself');
    cy.get('.tellus__dropdown').type('Chennai, Tamil Nadu, India');
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    cy.contains('button', 'READY!').click();
    cy.wait(2000);
    cy.contains('button', 'skip for now >').click({force:true});
    
    })
//not completed yet some error in redirecting url
    it.only('forget password', () => {
      
      const startStr = 'x3IhzZ5YUFU3xRWkCJI4aLVPC-2BOoHahfDU-2BROGlySass0TTVgllosmDa-2FaVEbjjZN-2FuCMhKKtmBUzbdxwO9z-2F'
      const endStr = '-3D'
      cy.visit('https://app.staging.rebelbase.co/');
      cy.get('.login__forgotpass').click();
      cy.get('.forgot-pass__input').clear();
      cy.get('.forgot-pass__input').type('rebelbasetesthub+2@gmail.com')
      cy.get('.forgot-pass__btn').click();
      cy.get('.popUp__note').contains('Check');
      cy.get('.notification-dismiss').click();
      cy.wait(5000)
      cy.task("gmail:get-messages", {
        options: {
          from: "info@rebelbase.co",
          subject: "Reset your RebelBase account password",
          include_body: true,
          // before: new Date(2021, 9, 24, 12, 31, 13), // Before September 24rd, 2019 12:31:13
          //  after: new Date(2021, 7, 23) // After August 23, 2019
        }
      }).then(emails => {
        assert.isAtLeast(
          emails.length,
          1,
          "Expected to find at least one email, but none were found!"
        );
  
        const body = emails[0].body.html;

        assert.isTrue(
          body.indexOf(
  
            "http://url3042.rebelbase.co/ls/click?upn=x3IhzZ5YUFU3xRWkCJI4aLVPC-2BOoHahfDU-2BROGlySass0TTVgllosmDa-2FaVEbjjZN-2FuCMhKKtmBUzbdxwO9z-2F"
  
          ) >= 0,
          "Found reset link!"
        );
  
        var token = extractData(body, startStr, endStr);
        
        cy.log(`http://url3042.rebelbase.co/ls/click?upn=${token}-3D`)
        
        cy.visit(`http://url3042.rebelbase.co/ls/click?upn=${token}-3D`)
       // return token;
        
      })

      //cy.visit("https://url3042.rebelbase.co/ls/click?upn=x3IhzZ5YUFU3xRWkCJI4aLVPC-2BOoHahfDU-2BROGlySass0TTVgllosmDa-2FaVEbjjZN-2FuCMhKKtmBUzbdxwO9z-2F`${token}`-3D")
    })

});