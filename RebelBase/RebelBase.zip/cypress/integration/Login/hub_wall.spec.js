describe('', () => {
  it.skip('Checks Inactive Hub [testgroupmember]', () => {
    cy.login('testgroupmember@rebelbase.co', Cypress.env('password'))
    cy.wait(5000);
    cy.url().should('include', '/profile/2470');
    cy.getCookie('token').should('exist');
  });
});
