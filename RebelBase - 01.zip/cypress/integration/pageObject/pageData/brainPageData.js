const brainPageData = {
    brainURL:'hubs/26/brain',
    testHubAdmin2Email: 'testhubadmin+2@rebelbase.co{enter}',
    invitationResentMessage: 'Invitation resent!',
    invitationDeleteMessage: 'Invitation deleted.',
    invitationSuccessMessage: 'Succesfully sent invite to:',
}
export { brainPageData }