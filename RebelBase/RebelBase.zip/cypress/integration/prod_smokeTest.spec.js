/// <reference types="cypress" />

import "cypress-real-events/support";

describe('production', () => {

  
 
  it('login application', function () {
   


    cy.visit("https://rebelbase.co/")
    
    cy.get('#catapultCookie').click()
    cy.get('.public__log-btn').contains('Log In').click();
    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.get('[name="password"]').type(Cypress.env('password'));
  
    cy.get('.login__btn').click();

  });
  it('create project', function () {
    cy.visit("https://rebelbase.co/")
    cy.get('#catapultCookie').click()
    cy.get('.public__log-btn').contains('Log In').click();
    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.get('[name="password"]').type(Cypress.env('password'));
  
    cy.get('.login__btn').click();
    cy.wait(8000)
    cy.visit('https://app.rebelbase.co/project/create-project  ');
    cy.wait(5000)
    //cy.get('.notification-dismiss').click({ force: true });
    cy.get('.sideNav__add-btn').click();
    cy.get(':nth-child(1) > :nth-child(2) > .form-control').clear();
    cy.get(':nth-child(1) > :nth-child(2) > .form-control').type(Cypress.config('randomname'));
    //cy.get(':nth-child(1) > :nth-child(2) > .form-control').type(testproject12132);
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');

    cy.get('#-google-places-autocomplete-suggestion--0').click();
    cy.get(':nth-child(3) > .form-control').select('2');
    //cy.get(':nth-child(4) > .form-control').select('17');
    cy.get('.cProj__btn').click();
    cy.wait(8000);
    cy.get('.index-header__projName').contains(Cypress.config('randomname'));
    //cy.get('.sideNav__add-team-btn').click();
    cy.get('.inviteForm__input').click();
    cy.get('.inviteForm__input').clear();

    cy.get('.inviteForm__input').type(Cypress.env('member'));

    cy.get('.inviteTeam__btn').click();
    cy.get('.btn-x').click({ force: true });
  });
  it('create group', function () {

    cy.visit("https://rebelbase.co/")
    cy.get('#catapultCookie').click()
    cy.get('.public__log-btn').contains('Log In').click();
    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.get('[name="password"]').type(Cypress.env('password'));
  
    cy.get('.login__btn').click();
    cy.wait(5000)
    //cy.get('.notification-dismiss').click({ force: true });
    cy.get(':nth-child(1) > .arrow-up').click();
    cy.get('.sideNav__link--groups').click();
    cy.wait(5000);
    cy.get('.notification-dismiss').click();
    cy.get('.group-overview__add-btn').click();
    cy.get('.create-group__name').clear({ force: true });
    cy.get('.create-group__name').type(Cypress.config('randomname'));
    //cy.get('.create-group__name').type('testproject12132');
    cy.get('.create-group__select-btn').click();
    cy.get('.btn-wrap > .btn-main').click();
    cy.wait(3000);
    cy.get('[data-testid=group_name]').should('have.text',Cypress.config('randomname'))
    cy.visit('https://app.rebelbase.co/hubs/26/groups');
    cy.wait(3000);
    //cy.get('.notification-dismiss').click(this.timeout(2000));
    cy.get('.search-input').clear();
    cy.get('.search-input').type(Cypress.config('randomname'));
    cy.get(':nth-child(1) > div.group-overview__title-wrap > div > div > button:nth-child(2)').click({ force: true });
    cy.get('[data-testid=customModal_firstChoice]').click();

  });
  it('add activity', function () {

    cy.visit("https://rebelbase.co/")
    cy.get('#catapultCookie').click()
    cy.get('.public__log-btn').contains('Log In').click();
    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.get('[name="password"]').type(Cypress.env('password'));
  
    cy.get('.login__btn').click();
    cy.wait(10000);
   // cy.get('.notification-dismiss').click({ force: true });
    cy.get('.arrow-up').contains('Dev Hub').click();
    cy.get('.sideNav__link--activity').click();
    cy.get('.btn__x').click()
    cy.contains('Add your thoughts').click({ force: true });
    cy.xpath("//button[@type='button']//h3[contains(text(),'Post')]").click();
    cy.get('.dialog__main-box').type('post cypress automation');
    cy.get('.dialog__submit').click();
    cy.get(':nth-child(1) > .post__header > .post__header__options > .post__header__drpdown-btn').realHover();

  });
  it('create event', function () {
    cy.visit("https://rebelbase.co/")
    cy.get('#catapultCookie').click()
    cy.get('.public__log-btn').contains('Log In').click();
    cy.get('input[name="email"]').type(Cypress.env('username'));
    cy.get('[name="password"]').type(Cypress.env('password'));
  
    cy.get('.login__btn').click();

    cy.wait(10000);
    cy.get('.notification-dismiss').click({ force: true });
    cy.get(':nth-child(1) > .arrow-up').click()
    cy.get('.sideNav__link--events').click();
    cy.get('.btn-main').click();

    cy.get('.createEvent__field__name--title').clear({ force: true });
    //cy.get('.createEvent__field__name--title').type('testevent111');
    cy.get('.createEvent__field__name--title').type(Cypress.config('randomname'));
    // cy.get('#rw_1_input').click();
    // cy.get('.createEvent__start-date > .createEvent__field__date > .rw-datetime-picker > .rw-widget-picker > .rw-select > .rw-btn').click();
    cy.get('#rw_1_input').click({force:true});
    cy.get('#rw_1_input').type('Aug 20, 2021');
    cy.get('#rw_2_input').click({force:true})
    cy.get('#rw_2_input').type('8:00am');
    cy.get('#rw_3_input').click({force:true})
    cy.get('#rw_3_input').type('Dec 30, 2021');
    cy.get('#rw_4_input').click({force:true})
    cy.get('#rw_4_input').type('8:00am');


    cy.get('#-google-places-autocomplete-input').clear({force:true});
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(2000);
    cy.get('#-google-places-autocomplete-suggestion--0').click({force:true});
    cy.get('.createEvent__field__type').select('3');
    cy.get(':nth-child(2) > .createEvent__round-choice').click();

    cy.get(':nth-child(3) > .createEvent__round-choice').click();

    cy.get('.createEvent > .btn-wrap > .btn-main').click();
    cy.wait(3000);
   // cy.get('[data-testid=ArrowDropDownIcon]').click();
  //  cy.get('[data-testid=LogoutIcon]').click();
 // cy.get(':nth-child(1) > .arrow-up').contains('Dev Hub').click();

  });

  it(`Signup application and logout`, () => {
    cy.visit("https://rebelbase.co/")
    cy.get('#catapultCookie').click()
    cy.get('.public__signup-btn').click();  
   
    cy.get('[name="firstName"]').clear();
    cy.get('[name="firstName"]').type('testtest');
    cy.get('[name="lastName"]').clear();
    cy.get('[name="lastName"]').type('sur');
    cy.get('[name="email"]').clear();
    cy.get('[name="email"]').type(Cypress.config('email'));
    cy.get('[name="password"]').clear();
    cy.get('[name="password"]').type('testtest');
    cy.get('[name="confirmPassword"]').clear();
    cy.get('[name="confirmPassword"]').type('testtest');
    cy.get('#allowAll').click();
    cy.get('#promotionalEmails').click();
    cy.get('.sign-up__btn').click({ force: true });
    cy.wait(10000);
    cy.url().should('include', '/profile');
    cy.get('#-google-places-autocomplete-input').clear();
    cy.get('#-google-places-autocomplete-input').type('pune');
    cy.wait(3000);
    cy.get('#-google-places-autocomplete-suggestion--0').click();
    cy.get('.tellus__wrap > .btn-main').click();
    cy.get('.btn-skip').click({ force: true });
   // cy.get('[aria-label="menu"] > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').contains('test')
    cy.get('a > .btn-link').contains('Create a Project')
   
  });
 
});
