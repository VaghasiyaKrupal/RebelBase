const prodSmokeTestPageSelector = {
    acceptCookiesVutton: '#catapultCookie',
    loginButton: "//button[contains(text(),'Log In')]",
    signUpButton:"//button[contains(text(),'Sign Up')]",
}
export { prodSmokeTestPageSelector }