const projectProfilePageSelector = {
    cancelButton:'//button[text()="cancel"]',
    uploadImage:'#img-upload',
    savelogoButton:'//button[normalize-space()="Save logo to project page"]',
}

export{projectProfilePageSelector}