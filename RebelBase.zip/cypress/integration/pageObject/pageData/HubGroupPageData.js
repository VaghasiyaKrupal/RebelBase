const hubGroupPageData = {
    emailID:'testhubadmin+1@rebelbase.co',
    password:'testtest',
    groupNameExistMessage:'Group name has already been taken!',
}
export{hubGroupPageData}