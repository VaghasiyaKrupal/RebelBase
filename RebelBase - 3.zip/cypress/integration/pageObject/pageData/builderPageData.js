const builderPageData = {
    builderAnswerPage: '/project/1511/builders/1/topics/1/answer',
    loremWord:'Lorem Ipsum',
    saveAnswer:'Answer saved!',
    deleteConfirmMessage:'Are you sure you want to leave this page without publishing?',
    ansLink:'https://www.youtube.com/watch?v=eL2xrOIaFhM',
}
export { builderPageData }