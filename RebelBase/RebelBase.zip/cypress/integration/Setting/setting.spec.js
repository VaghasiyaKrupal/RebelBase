describe('', () => {
  it('send,snudge delete project invitation from setting page', function () {

    cy.login(Cypress.env('username'), Cypress.env('password'));
    cy.get('.css-bs6fjm').click();
    cy.get('[tabindex="0"][role="menuitem"] > .css-70qvj9').click();
    cy.get('.notification-dismiss').click();
    cy.get('.sideBar > ul > :nth-child(5) > span').click();
    cy.get('.btn-link').click();
    cy.get('.inviteForm__input').clear();
    cy.get('.inviteForm__input').type('testhubadmin+2@rebelbase.co');
    cy.get('.inviteTeam__btn').click();
    cy.get('.inviteTeam__btn__nudge').click();
    cy.get('.popUp__note').click();
    cy.get('.btn-delete').click();
    cy.get('.btn-x').click();

  });


  it('change project details', function () {

    cy.login(Cypress.env('username'), Cypress.env('password'));
    cy.get('[data-testid="ArrowDropDownIcon"]').click();
    cy.get('[tabindex="0"][role="menuitem"] > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').click();
    cy.get('.notification-dismiss').click();
    cy.get('.sideBar > ul > :nth-child(5) > span').click();
    cy.get('#name').clear();
    cy.get('#name').type('myproejt22');
    cy.get('#-google-places-autocomplete-input').clear().type('p');
    //  cy.get('.content__input').type('p');
    cy.get('#-google-places-autocomplete-suggestion--1').click();
    cy.get('#industry_id').select('12');
    cy.get('#project_stage').select('planning');
    cy.get('.btn--save > input').click();
    // cy.get('.popUp__note').should('have.text', 'Project settings saved!');
    // cy.get('.notification-dismiss').click({force: true});
    cy.get('.edit-pen').click();
    cy.get('.person__role__edit-wrap > input').clear();
    cy.get('.person__role__edit-wrap > input').type('admin');
    cy.get('.btn-save').click();
    cy.get('.popUp__note').should('have.text', 'Title changed!');

  });
  it('language change', function () {
    cy.login(Cypress.env('username'), Cypress.env('password'));
    cy.get('[data-testid="ArrowDropDownIcon"]').click();
    cy.get('a.MuiMenuItem-root > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').click();
    cy.get('.css-7pf6at > .css-d0uhtl > .MuiTypography-root').click();
    cy.get('.MuiList-root > :nth-child(5) > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').click();
    cy.get('.notification-dismiss').click();
    cy.get('[data-testid="ArrowDropDownIcon"] > path').click();
    cy.get('#more-menu > .MuiPaper-root > .MuiList-root').click({
      force: true
    });
    cy.get('.MuiList-root > :nth-child(4) > .css-70qvj9 > .MuiBox-root > .MuiTypography-root').click();

  });
});