const eventData = {
    eventDescription:'cypress automation description',
    postMessage:'post from automation',
    bioUpdateMessage:'Bio updated successfully.',
    supportEmail:'rebelbasetesthub+2@gmail.com',
    compititorEmail:'rebelbasetesthub+1@gmail.com',
}
export{eventData}